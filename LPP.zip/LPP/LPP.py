from tkinter import *
import time
import os
while True:
    filelocation = input("Please enter the directory of your LPP file: ")
    filee = open(filelocation,'r').readlines()
    for line in filee:
        if not "loop(" in str(line):
            if not str(line):
                print('ERROR CODE 7: Script service not found. You might not have saved your code?')
            elif "cout('" in str(line):
                a = str(line).partition("('")[2].partition("');")[0]
                print("Output: " + a)
            elif "lppmath.solve(" in str(line):
                b = str(line).partition('(')[2].partition("+")[0]
                c = str(line).partition('+')[2].partition(');')[0]
                print("Output: " + str(int(b) + int(c)))
            elif "lppstring::concat<<" in str(line):
                d = str(line).partition('<<')[2].partition("~")[0]
                e = str(line).partition('~')[2].partition('>>;')[0]
                print("Output: " + str(d + e))
            elif "lppstring::getlc(" in str(line):
                f = str(line).partition("('")[2].partition("');")[0]
                print("Output: " + str(len(f)))
            elif "forcount a" in str(line):
                g = str(line).partition('a')[2].partition("end1")[0]
                h = str(line).partition('b')[2].partition('end2')[0]
                for i in range(int(g),int(h)):
                    print("Output: " + str(i))
            elif "lce.build(vector<int>; n * [" in str(line):
                y = str(line).partition("['")[2].partition("']);")[0]
                window = Tk()
                window.title(y)
                window.mainloop()
            elif "trace('" in str(line):
                xy = str(line).partition("('")[2].partition("');")[0]
                os.system("tracert {}".format(str(xy)))
            elif "cout.flush();" in str(line):
                os.system('cls')
            elif "tsleep(" in str(line):
                zy = str(line).partition("(")[2].partition(");")[0]
                time.sleep(int(zy))
            elif "paktc();" in str(line):
                os.system('pause')
            elif "close();" in str(line):
                exit()
            elif "lce.mpopup(" in str(line):
                zan = str(line).partition("('")[2].partition("');")[0]
                os.system("msg * " + str(zan))
            elif "epoch.tick()" in str(line):
                epoch_time = int(time.time())
                print(epoch_time)
            elif "script.access.remove()" in str(line):
                print("ERROR CODE 4 LPPSCRIPTSECURITY: No access")

                    


            elif "end()" in str(line):
                print("Script has been terminated. No further code will be run.\n")
                break
        else:
            zp = str(line).partition("(")[2].partition(");")[0]
            for ij in range(1,int(zp)):
                if not str(line):
                    print('ERROR CODE 7: Script service not found. You might not have saved your code?')
                elif "cout('" in str(line):
                    a = str(line).partition("('")[2].partition("');")[0]
                    print("Output: " + a)
                elif "lppmath.solve(" in str(line):
                    b = str(line).partition('(')[2].partition("+")[0]
                    c = str(line).partition('+')[2].partition(');')[0]
                    print("Output: " + str(int(b) + int(c)))
                elif "lppstring.concat<<" in str(line):
                    d = str(line).partition('<<')[2].partition("~")[0]
                    e = str(line).partition('~')[2].partition('>>;')[0]
                    print("Output: " + str(d + e))
                elif "lppstring.getlc(" in str(line):
                    f = str(line).partition("('")[2].partition("');")[0]
                    print("Output: " + str(len(f)))
                elif "forcount a" in str(line):
                    g = str(line).partition('a')[2].partition("end1")[0]
                    h = str(line).partition('b')[2].partition('end2')[0]
                    for i in range(int(g),int(h)):
                        print("Output: " + str(i))
                elif "lce.build(vector<int>; a * [" in str(line):
                    y = str(line).partition("['")[2].partition("']);")[0]
                    window = Tk()
                    window.title(y)
                    window.mainloop()
                elif "trace('" in str(line):
                    xy = str(line).partition("('")[2].partition("');")[0]
                    os.system("tracert {}".format(str(xy)))
                elif "cout.flush();" in str(line):
                    os.system('cls')
                elif "tsleep(" in str(line):
                    zy = str(line).partition("(")[2].partition(");")[0]
                    time.sleep(int(zy))
                elif "paktc();" in str(line):
                    os.system('pause')
                elif "lce.mpopup(" in str(line):
                    zan = str(line).partition("('")[2].partition("'');")[0]
                    os.system("msg * " + str(zan))
                elif "close();" in str(line):
                    exit()
                elif "epoch.tick()" in str(line):
                    epoch_time = int(time.time())
                    print(epoch_time)
                elif "script.access.remove()" in str(line):
                    print("Error code 5: Not accessible in loop")


                elif "end();" in str(line):
                    print("Script has been terminated. No further code will be run.\n")
                    break
